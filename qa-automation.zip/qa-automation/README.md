# DSS Validation – Automated Test (Part 2)

Automates **TC-01** from the Part 1 test design: *"Successful validation of a
signed PDF (happy path)"*, against the public DSS Demonstration WebApp:
http://dss.nowina.lu/validation

**Why this test case:** it is the core happy path the whole feature exists
for (AC1: upload + submit → report is produced) and gives an immediate,
coarse signal on AC2 (the report exposes signature/certificate content). If
this breaks, every other scenario is moot — and it's simple and stable
enough (one file upload, one click) to automate reliably without needing a
larger framework, which fits the "small, well-written test" brief.

## Stack

- Java 17, Maven
- Selenium **4.24.0** (WebDriver) — version pinned in `pom.xml`
  (`<selenium.version>`), well above the 4.6 threshold where Selenium
  Manager (automatic driver-binary resolution) was introduced, so no
  manual chromedriver install/config is ever needed regardless of what's
  already on your machine
- JUnit 5

## Install & configure

1. Install a JDK 17+ and Maven 3.8+.
2. Have Google Chrome installed locally (the test drives Chrome; Selenium
   Manager will fetch a matching chromedriver on first run).
3. Clone/copy this project. The signed PDF used as test data is already
   bundled at `src/test/resources/test-valid-signature-signed-LTA.pdf` (the
   file supplied with the exercise — a PAdES-LTA signed PDF, i.e. it carries
   long-term-validation data, so it should validate cleanly regardless of
   how long from now this test is run).

No further configuration is required to run against the public instance.

## Run

```bash
mvn test
```

Optional overrides:

```bash
# point at a different environment (e.g. a staging DSS instance)
mvn test -Ddss.base.url=http://dss.nowina.lu/validation

# watch it run in a visible browser window instead of headless
mvn test -Dbrowser.headless=false

# live-demo mode: visible window, kept open 8s after the test finishes so
# the final report stays on screen instead of disappearing instantly
mvn test -Dbrowser.headless=false -Ddemo.pause.seconds=8
```

## Pass/fail signal

Standard JUnit/Surefire output: `mvn test` exits with status `0` and prints
`BUILD SUCCESS` when the test passes, non-zero with `BUILD FAILURE` and the
failing assertion message otherwise. A timestamped screenshot of the final
page is saved to `target/screenshots/tc01-report-<yyyy-MM-dd_HH-mm-ss>.png`
on every run (nothing gets overwritten, so you keep a history of past runs).

## Note on console warnings

Selenium may log a "no matching CDP version" warning on very recent Chrome
releases (Chrome DevTools Protocol bindings are only needed for advanced
features — network interception, JS console access — that this test doesn't
use). It's silenced via a `java.util.logging` level bump in the test class'
static initializer, so you shouldn't see it in the console output.

## What the test does

1. Opens the validation page.
2. Selects `test-valid-signature-signed-LTA.pdf` in the "Signed file" input
   (`input[name='signedFile']` — the field name is taken from the DSS demo
   webapp's own `ValidationController` source, not guessed from the
   rendered HTML).
3. Clicks the Submit button.
4. Waits for the validation report to appear.
5. Asserts:
   - no server error page was returned (guards against a silent regression
     turning AC1 into a 500),
   - the resulting page contains both "signature" and "certificate" content,
     as a first check on AC2.

## Verified against the live site

This test has been run successfully against the real
http://dss.nowina.lu/validation, with the actual signed PDF supplied for
this exercise (`test-valid-signature-signed-LTA.pdf`, a PAdES-BASELINE-LTA
signature). The report confirms `Indication: TOTAL_PASSED`, qualification
`QESig`, so both the automation and the test data are known-good, not just
theoretically correct. A couple of environment-specific things came up
along the way and are worth knowing about if you re-run this elsewhere:

- **Chromedriver version conflicts**: if you have an old `chromedriver.exe`
  sitting in your system `PATH` (e.g. from a previous manual setup), it
  will be picked up ahead of Selenium Manager's auto-resolved version and
  can fail with a version-mismatch error. Remove it from `PATH` (or update
  it) so Selenium Manager can do its job.
- **Visible-window runs on a corporate/managed machine**: with
  `-Dbrowser.headless=false`, the Chrome process launches (visible in Task
  Manager) but its window may not actually render on screen — this was
  observed to be an environment/security-policy effect (common with
  corporate EDR/antivirus software sandboxing automation-launched
  windows), not a bug in the test. Headless mode plus the saved screenshot
  is the reliable way to get visual evidence in that kind of environment.

## Possible next steps (not done here, to keep this small on purpose)

- Add TC-07/TC-08 (unsupported file type) as a second test once the first is
  confirmed against the live DOM — they're the other high-priority AC.
- Parameterize the report assertions per acceptance criterion (separate
  assertions for qualification / signature details / certificate /
  timestamp sections) once exact report selectors are known.
- Wire into CI with the browser matrix DSS itself is likely tested against.
