package lu.nowina.dssqa;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Duration;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * Automates TC-01 from the Part 1 test design:
 * "Successful validation of a signed PDF (happy path)" — covers AC1 (the
 * system processes the file and displays a validation report) and gives a
 * first, coarse-grained signal on AC2 (the report exposes signature /
 * certificate related content).
 *
 * <p>Chosen for automation because it is the core happy path the whole
 * feature exists for: if it breaks, every other scenario is moot, and it is
 * simple/stable enough (single file upload + submit) to automate reliably
 * without fighting a large, brittle framework.</p>
 */
class ValidateSignedPdfTest {

    private static final String BASE_URL =
            System.getProperty("dss.base.url", "http://dss.nowina.lu/validation");
    private static final boolean HEADLESS =
            Boolean.parseBoolean(System.getProperty("browser.headless", "true"));
    private static final Duration TIMEOUT = Duration.ofSeconds(30);
    private static final int DEMO_PAUSE_SECONDS =
            Integer.parseInt(System.getProperty("demo.pause.seconds", "0"));

    static {
        // Silence Selenium's benign "no matching CDP version" warnings.
        // CDP (Chrome DevTools Protocol) bindings are only needed for
        // advanced features (network interception, JS console access) that
        // this test does not use, so a missing/mismatched CDP version is
        // not an actionable problem here - just noise on modern Chrome
        // releases that are newer than Selenium's bundled CDP versions.
        Logger.getLogger("org.openqa.selenium").setLevel(Level.SEVERE);
    }

    private WebDriver driver;

    @BeforeEach
    void setUp() {
        ChromeOptions options = new ChromeOptions();
        if (HEADLESS) {
            options.addArguments("--headless=new");
            // Extra-tall viewport so the screenshot captures the full
            // report (Simple Report + Timestamps + Document Information)
            // without needing to scroll — the DSS report page is longer
            // than a normal screen.
            options.addArguments("--window-size=1800,1600");
            options.addArguments("--no-sandbox");
            options.addArguments("--disable-dev-shm-usage");
        } else {
            // Visible run (e.g. for a live demo): explicit on-screen
            // position/size, and none of the Linux/CI-only flags that can
            // interfere with window rendering on Windows.
            options.addArguments("--window-position=0,0");
            options.addArguments("--window-size=1280,900");
            // Uncomment and adjust if Selenium ever resolves the wrong
            // binary (e.g. a headless-shell build instead of full Chrome):
            // options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
        }
        // Selenium Manager (bundled with Selenium 4.6+) resolves and downloads
        // a matching chromedriver automatically — no manual driver setup needed.
        driver = new ChromeDriver(options);
    }

    @Test
    @DisplayName("TC-01: uploading a valid signed PDF and submitting produces a validation report")
    void validateSignedPdf_producesSuccessfulReport() throws URISyntaxException, IOException {
        // --- Step 1: open the validation page ---
        driver.get(BASE_URL);

        // --- Step 2: select the sample signed PDF as the "Signed file" ---
        // The form field is named "signedFile" server-side (Spring MVC
        // ValidationController#ALLOWED_FIELDS), which is the most stable
        // selector available without relying on generated CSS classes.
        WebElement fileInput = driver.findElement(By.cssSelector("input[name='signedFile']"));
        fileInput.sendKeys(sampleSignedPdfPath());

        // --- Step 3: submit the form ---
        WebElement submitButton = driver.findElement(
                By.cssSelector("button[type='submit'], input[type='submit']"));
        submitButton.click();

        // --- Step 4: wait for the report to be produced ---
        WebDriverWait wait = new WebDriverWait(driver, TIMEOUT);
        wait.until(reportIsDisplayed());

        // --- Step 5: assertions (AC1 + a first pass at AC2) ---
        String pageText = driver.findElement(By.tagName("body")).getText().toLowerCase(Locale.ROOT);

        assertFalse(
                pageText.contains("whitelabel error") || pageText.contains("http status 500"),
                "The application returned an error page instead of a validation report");

        assertTrue(
                pageText.contains("signature") && pageText.contains("certificate"),
                "The report page is not showing the expected signature/certificate content");

        // Best-effort evidence for the test run, regardless of outcome.
        saveScreenshot("tc01-report-" + timestampForFileName() + ".png");
    }

    /**
     * Waits until the initial upload form is gone AND report-like content is
     * present. Written defensively since the exact DOM of the report screen
     * was not directly inspectable from this environment (no live browser
     * access) — see README "Known limitation" section. If this condition
     * proves too loose/strict against the real DOM, replace it with a wait
     * on a concrete report container id/class once inspected in a browser.
     */
    private ExpectedCondition<Boolean> reportIsDisplayed() {
        return d -> {
            boolean uploadFormGone = d.findElements(By.cssSelector("input[name='signedFile']")).isEmpty();
            String text = d.findElement(By.tagName("body")).getText().toLowerCase(Locale.ROOT);
            boolean reportKeywordsPresent = text.contains("signature") && text.contains("certificate");
            return uploadFormGone && reportKeywordsPresent;
        };
    }

    private static final String SAMPLE_FILE_NAME = "test-valid-signature-signed-LTA.pdf";

    private String sampleSignedPdfPath() throws URISyntaxException {
        // Resolve the bundled sample from src/test/resources, works both
        // from an IDE and from `mvn test` (test-classes on the classpath).
        Path fromClasspath = Paths.get(
                getClass().getClassLoader().getResource(SAMPLE_FILE_NAME).toURI());
        return fromClasspath.toAbsolutePath().toString();
    }

    private void saveScreenshot(String fileName) {
        try {
            Path dir = Paths.get("target", "screenshots");
            Files.createDirectories(dir);
            File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
            // No REPLACE_EXISTING: each run gets its own timestamped file
            // name (see timestampForFileName()), so nothing is ever
            // overwritten and you keep a history of past runs.
            Files.copy(src.toPath(), dir.resolve(fileName));
        } catch (Exception e) {
            // Screenshot capture is best-effort evidence, never fail the test for it.
            System.err.println("Could not save screenshot: " + e.getMessage());
        }
    }

    private String timestampForFileName() {
        return java.time.LocalDateTime.now()
                .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss"));
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            // For live demos: keep the browser open for a few seconds after
            // the test finishes so the report stays visible on screen,
            // instead of vanishing the instant the assertions complete.
            // Run with -Ddemo.pause.seconds=8 (or edit the default above).
            if (DEMO_PAUSE_SECONDS > 0) {
                try {
                    Thread.sleep(DEMO_PAUSE_SECONDS * 1000L);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
            driver.quit();
        }
    }
}
